//
//  ViewController.swift
//  UsernameApp
//
//  Created by Kadali,Hema Durga Kiran on 1/25/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var username: UITextField!
    
    
    @IBOutlet weak var userLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
   

    @IBAction func Signin(_ sender: UIButton) {
        var input = username.text!
        userLabel.text = "The given username is \(input)!"
    }
    
}

