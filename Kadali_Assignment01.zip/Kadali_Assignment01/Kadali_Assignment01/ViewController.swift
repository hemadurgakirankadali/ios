//
//  ViewController.swift
//  Kadali_Assignment01
//
//  Created by Kadali,Hema Durga Kiran on 2/2/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var FName: UITextField!
    
    
    @IBOutlet weak var LName: UITextField!
    
    
    @IBOutlet weak var DOB: UITextField!
    
    
    @IBOutlet weak var Det: UILabel!
    
    
    @IBOutlet weak var FulLabel: UILabel!
    
    @IBOutlet weak var InitialLabel: UILabel!
    
    
    @IBOutlet weak var Age: UILabel!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func Submit(_ sender: Any) {
        var firstname = FName.text!;
        var lastname = LName.text!;
        let Dateofbirth = Int(DOB.text!)
        let k = Date()
        let i = Calendar.current
        let r = i.component(.year, from: k)
        let l = r - Dateofbirth!
        Det.text = "Details"
        FulLabel.text = "Full Name : \(lastname) \(firstname)"
        InitialLabel.text = "initials : \(lastname.first!) \(firstname.first!)"
        Age.text = "Age : \(l)" ;
    }
    
    @IBAction func Reset(_ sender: Any) {
        FName.text = ""
        LName.text = ""
        DOB.text = ""
        Det.text = ""
        FulLabel.text = ""
        InitialLabel.text = ""
        Age.text = ""
    }
    
}

