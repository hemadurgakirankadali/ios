//
//  ViewController.swift
//  Kadali_CalculatorApp
//
//  Created by Kadali,Hema Durga Kiran on 2/16/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var Label: UILabel!
    
    var operand1 = ""
    var operand2 = ""
    var rest = ""
    var operand = ""
    var aoperand = false
    var coperand = ""
    var mog = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    func sum(_ numbers:String){
        if Label.text == "0" {
            Label.text = ""
    }
    if !aoperand{
        Label.text! += numbers
        operand1 += numbers
    }else{
        print(mog)
        if !mog {
            Label.text! += numbers
            operand2 += numbers
        }else{
            Label.text = ""
            Label.text! += numbers
            operand2 += numbers
        }
    }
    }
    @IBAction func btn7(_ sender: UIButton) {
        sum("7")
    }
    @IBAction func btn8(_ sender: UIButton) {
        sum("8")
    }
    @IBAction func btn9(_ sender: UIButton) {
        sum("9")
    }
    
    @IBAction func btn4(_ sender: UIButton) {
        sum("4")
    }
    @IBAction func btn5(_ sender: UIButton) {
        sum("5")
    }
    @IBAction func btn6(_ sender: UIButton) {
        sum("6")
    }
    @IBAction func btn1(_ sender: UIButton) {
        sum("1")
    }
    @IBAction func btn2(_ sender: UIButton) {
        sum("2")
    }
    @IBAction func btn3(_ sender: UIButton) {
        sum("3")
    }
    @IBAction func btn0(_ sender: UIButton) {
        sum("0")
    }
    @IBAction func btndot(_ sender: UIButton) {
        sum(".")
    }
    
    func remove(){
        operand1 = ""
        operand2 = ""
        aoperand = false
        operand = ""
        coperand = ""
        Label.text = "0"
        mog = false
    }
    
    @IBAction func BtnAC(_ sender: UIButton) {
        remove()
    }
    
    @IBAction func btnc(_ sender: UIButton) {
        if(!Label.text!.isEmpty && !aoperand){
            Label.text!.removeLast()
            operand1 = Label.text!
        }else{
            Label.text!.removeLast()
            operand2 = Label.text!
        }
    }
    
    
    @IBAction func btnARS(_ sender: UIButton) {
        if operand1 == ""{
            Label.text = "-" + Label.text!
            operand1 = "\(Label.text!)"
        }
        else{
            Label.text = "-" + Label.text!
            operand2 = "\(Label.text!)"
        }
    }
    
    func mathoperations(_ operation: String)->String {
        print("\(operand1),\(operand2)")
        if operand1 != "" && operand2 != "" {
            if operand == "+"{
                operand1 = String(Double(operand1)! + Double(operand2)!)
                coperand = operand2
                operand2 = ""
                return String (operand1)
            }
            if operand == "-"{
                operand1 = String(Double(operand1)! - Double(operand2)!)
                coperand = operand2
                operand2 = ""
                return String (operand1)
            }
            if operand == "*"{
                operand1 = String(Double(operand1)! * Double(operand2)!)
                coperand = operand2
                operand2 = ""
                return String (operand1)
             }
            if operand == "/"{
                operand1 = String(Double(operand1)! / Double(operand2)!)
                coperand = operand2
                operand2 = ""
                return String (operand1)
              }
            if operand == "%"
            {
              let k1 = Double(operand1)!
                let k2 = Double(operand2)!
                var i = k1.remainder(dividingBy: k2)
                operand1 = String(i)
                coperand = operand2
                operand2 = ""
                return String(operand1)
            }
            
        }
        return ""
    }
    func furesult(_ res:String)->String{
    let r = Double(res)!
    var resstr = String(round(r*100000)/100000.0)
    if resstr.contains(".0"){
        resstr.removeSubrange(resstr.index(resstr.endIndex,offsetBy: -2)..<resstr.endIndex)
    }
    return resstr
}
    @IBAction func btndiv(_ sender: UIButton) {
        let s = mathoperations(operand)
        operand = "/"
        Label.text = (s != "") ? furesult(s) : ""
        if s != "" {
            if operand2 != "" {
                mog = true
                coperand = operand2;
                if aoperand{
                    rest = String(Double(s)! / Double(operand2)!)
                    print(rest)
                    if rest == "inf" {
                        Label.text! = "Not a number"
                    }else{
                        Label.text! = furesult(rest)
                    }
                }
            }
        }
        aoperand = true
    }
    
    @IBAction func btnmul(_ sender: UIButton) {
        let s = mathoperations(operand)
        operand = "*"
        coperand = ""
        Label.text = (s != "") ? furesult(s) : ""
        aoperand = true
    }
    
    @IBAction func btnsub(_ sender: UIButton) {
        let s = mathoperations(operand)
        operand = "-"
        Label.text = (s != "") ? furesult(s) : ""
        if s != "" {
            if operand2 != "" {
                mog = true
                coperand = operand2;
                if aoperand{
                    rest = String(Double(s)! - Double(operand2)!)
                    Label.text! = furesult(rest)
                }
            }
        }
        aoperand = true
    }
    
    @IBAction func btnadd(_ sender: UIButton) {
        let s = mathoperations(operand);
        print("s is \(s)")
        operand = "+"
        coperand = ""
        Label.text = (s != "") ? furesult(s) : ""
        aoperand = true
    }
    
    @IBAction func btnmod(_ sender: UIButton) {
        let s = mathoperations(operand);
        print("s is \(s)")
        operand = "%"
        coperand = ""
        Label.text = (s != "") ? furesult(s) : ""
        aoperand = true
    }
    
    
    @IBAction func btneq(_ sender: UIButton) {
        print("rest : \(Label.text!)")
        var output =  ""
        switch operand {
        case "+" :
            if coperand != "" {
                output = String(Double(operand1)! + Double(coperand)!)
                Label.text = furesult(output)
                operand2 = coperand
            }else{
                print(coperand)
                output = String(Double(operand1)! + Double(operand2)!)
                Label.text = furesult(output)
            }
            operand1 = output
            break
        case "-" :
            if coperand != "" {
                output = String(Double(operand1)! - Double(coperand)!)
                Label.text = furesult(output)
                operand2 = coperand
            }else{
                print(coperand)
                output = String(Double(operand1)! - Double(operand2)!)
                Label.text = furesult(output)
            }
            operand1 = output
            break
        case "/" :
            if Label.text == "Error" {
                remove()
            }else{
                if coperand != "" {
                    output = String(Double(operand1)! - Double(coperand)!)
                    if output == "inf" {
                        Label.text! = "Not a number"
                        return
                    }else{
                        Label.text = furesult(output)
                    }
                }else{
                    output = String(Double(operand1)! /  Double(operand2)!)
                        if output == "inf" {
                            Label.text! = "Not a number"
                            return
                        }else{
                            Label.text = furesult(output)
                }
            }
            }
                    operand1 = output
            break
        case "*" :
            if coperand != "" {
                output = String(Double(operand1)! * Double(coperand)!)
                Label.text = furesult(output)
                operand2 = coperand
            }else{
                print(coperand)
                output = String(Double(operand1)! * Double(operand2)!)
                Label.text = furesult(output)
            }
            operand1 = output
            break
        case "%" : if Label.text == "Error" {
            remove()
        }else{
            if coperand != "" {
                output = String((Double(operand1)?.truncatingRemainder(dividingBy: Double(coperand)!))!)
                if output == "inf" {
                    Label.text! = "Not a number"
                    return
                }else{
                    Label.text = furesult(output)
                }
            }else{
                output = String((Double(operand1)?.truncatingRemainder(dividingBy: Double(operand2)!))!)
                    if output == "inf" {
                        Label.text! = "Not a number"
                        return
                    }else{
                        Label.text = furesult(output)
            }
        }
        }
                operand1 = output
        default:
            Label.text = Label.text!
        }
    }
    
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

