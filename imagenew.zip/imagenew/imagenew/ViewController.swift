//
//  ViewController.swift
//  imagenew
//
//  Created by Kadali,Hema Durga Kiran on 2/25/23.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var image: UIImageView!
    
    
    @IBOutlet weak var label: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func displayimage(_ sender: UIButton) {
        
        //it is used to show image
        image.image = UIImage(named: "kohli")
        //it is used to show the text
        label.text = "king of cricket!"
    }
    
}


