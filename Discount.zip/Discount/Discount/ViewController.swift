//
//  ViewController.swift
//  Discount
//
//  Created by Palavelli,Anil Kumar on 2/27/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var enterAmount: UITextField!
    
    @IBOutlet weak var enterDiscountOutlet: UITextField!
    
    
    @IBOutlet weak var displayLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func calcuPriceBTN(_ sender: UIButton) {
        var amount = Double(enterAmount.text!)
        
        var discount = Double(enterDiscountOutlet.text!)
        
        var priceAfterDiscount = amount!-(amount!*discount!/100)
        displayLabel.text = "Price After Discount : $\(priceAfterDiscount)"
        
    }
    

}

