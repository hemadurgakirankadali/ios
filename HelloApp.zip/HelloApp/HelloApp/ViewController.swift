//
//  ViewController.swift
//  HelloApp
//
//  Created by Kadali,Hema Durga Kiran on 1/25/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var nameOutlet: UITextField!
    
    @IBOutlet weak var DisplayLabelOutlet: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func ClickButton(_ sender: UIButton) {
        //Read the input and store it assign it to a variable
        var input = nameOutlet.text!
        //perform string interpolation "Hello, Name!" and assign it to display label
        DisplayLabelOutlet.text = "Hello,\(input)!"
    }
    

}

